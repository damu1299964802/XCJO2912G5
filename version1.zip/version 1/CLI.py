# app/cli.py
import click
from flask.cli import with_appcontext
from app.models import db
from app.models.user import User

def init_app(app):
    app.cli.add_command(promote_user)

@click.command('promote-user')
@click.argument('username')
@with_appcontext
def promote_user(username):
    """将指定用户提升为管理员"""
    user = User.query.filter_by(username=username).first()
    if user is None:
        click.echo(f'用户 {username} 不存在')
        return
    
    user.is_admin = True
    db.session.commit()
    click.echo(f'用户 {username} 已被提升为管理员')