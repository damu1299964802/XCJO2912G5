# app/utils/upload.py
import os
from PIL import Image
from flask import current_app
from werkzeug.utils import secure_filename

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
MAX_FILE_SIZE = 2 * 1024 * 1024  # 2MB

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_avatar(file, user_id):
    if not file or not allowed_file(file.filename):
        return None
        
    # 检查文件大小
    if len(file.read()) > MAX_FILE_SIZE:
        file.seek(0)  # 重置文件指针
        return None
        
    # 创建上传目录
    upload_path = os.path.join(current_app.root_path, 'static/uploads/avatars')
    if not os.path.exists(upload_path):
        os.makedirs(upload_path)
    
    # 安全的文件名
    filename = f"avatar_{user_id}_{secure_filename(file.filename)}"
    filepath = os.path.join(upload_path, filename)
    
    try:
        # 保存并处理图片
        file.seek(0)  # 重置文件指针
        with Image.open(file) as img:
            # 转换为RGB模式（如果是PNG等格式）
            if img.mode != 'RGB':
                img = img.convert('RGB')
            
            # 创建正方形缩略图
            size = 200
            ratio = max(size/img.width, size/img.height)
            new_size = (int(img.width*ratio), int(img.height*ratio))
            img = img.resize(new_size, Image.Resampling.LANCZOS)
            
            # 裁剪为正方形
            left = (img.width - size)/2
            top = (img.height - size)/2
            right = (img.width + size)/2
            bottom = (img.height + size)/2
            img = img.crop((left, top, right, bottom))
            
            # 保存处理后的图片
            img.save(filepath, 'JPEG', quality=85)
        
        return filename
    except Exception as e:
        print(f"Error saving avatar: {e}")
        if os.path.exists(filepath):
            os.remove(filepath)
        return None