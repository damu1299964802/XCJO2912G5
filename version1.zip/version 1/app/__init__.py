# app/__init__.py
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from config import Config


db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message = '请先登录'

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)
    app.config['SECRET_KEY'] = 'your-secret-key'
    
    # 初始化扩展
    db.init_app(app)
    login_manager.init_app(app)
    
    with app.app_context():
        # 导入蓝图
        from app.routes.auth import bp as auth_bp
        from app.routes.main import bp as main_bp
        from app.routes.admin import bp as admin_bp  # 确保这行存在
        from app.routes.act import bp as interaction_bp
        
        # 注册蓝图
        app.register_blueprint(auth_bp)
        app.register_blueprint(main_bp)
        app.register_blueprint(admin_bp)  # 确保这行存在
        app.register_blueprint(interaction_bp)
        
        
        # 创建上传目录
        import os
        for directory in ['avatars', 'covers']:
            os.makedirs(os.path.join(app.root_path, 'static', 'uploads', directory), exist_ok=True)
        
        # 创建数据库表
        db.create_all()
    
    return app

@login_manager.user_loader
def load_user(id):
    from app.models import User
    return User.query.get(int(id))