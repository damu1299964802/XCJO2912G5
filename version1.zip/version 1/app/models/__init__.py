# app/models/__init__.py
from app import db

# 首先导入 User 模型，因为其他模型依赖它
from app.models.user import User
from app.models.media import Movie, Music, Game
from app.models.interaction import Like, Favorite  # 确保添加这一行
from app import db

__all__ = ['User', 'Movie', 'Music', 'Game']