# config.py
import os
from datetime import timedelta

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or \
        'sqlite:///' + os.path.join(os.path.dirname(os.path.abspath(__file__)), 'app.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    STEAM_API_KEY = 'B9751C82D347BA7CB1CC4BFBAACBC110'
    STEAM_DOMAIN = 'qq.com'
    OMDB_API_KEY = '9219defa'
    SPOTIFY_CLIENT_ID = 'e32fe288b030406dac7cae4d242f7266'
    SPOTIFY_CLIENT_SECRET = 'd87fef2135964a3bb67aa98f33e0f169'
    # 管理员注册码
    ADMIN_CODE = os.environ.get('ADMIN_CODE') or '123'
    
    # 上传文件配置
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size
    UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'app', 'static', 'uploads')
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}